const Discord = require('discord.js');
const ayarlar = require('../ayarlar.json')
exports.run = function(client, message) {
  
  let prefix  = ayarlar.prefix

const yardım = new Discord.MessageEmbed()
.setColor('Red color')
.setAuthor(`◈𝐅𝐢𝐯𝐞𝐦 𝐓𝐔𝐑𝐊𝐈𝐘𝐄 𝐂𝐎𝐌𝐌𝐔𝐍𝐈𝐓𝐘 𝙈𝙚𝙣𝙪 𝙃𝙤𝙨𝙜𝙚𝙡𝙙𝙞𝙣◈`)
.setDescription(`


:white_small_square: **=**  \`lp!kanal-koruma\` : **Kanal Koruma Aç/Kapat**
:white_small_square: **=**  \`lp!küfür-engel\`:  **Küfür Engel Aç/Kapat**
:white_small_square: **=**  \`lp!reklam-engel\` :  **Reklam Engel Aç/Kapat**
:white_small_square: **=**  \`lp!sohbet aç-kapat\` :  **Sohbeti Açıp Kapatırsınız**
:white_small_square: **=**  \`lp!ban\`: **Belirttiğiniz Kişiyi Sunucudan Banlarsınız**
:white_small_square: **=**  \`lp!unban\`:  **Belirttiğiniz Kişinin Banını Kaldırırsınız**
:white_small_square: **=**  \`lp!istatistik\`:  **Botun İstatistiklerini Atar**
:white_small_square: **=**  \`lp!temizle\`:  **Belirttiğiniz Sayıda Mesajı Siler**
:white_small_square: **=**  \`lp!ping\`:  **Pinginizi Ölçüp Atar**
:white_small_square: **=**  \`lp!avatar\`:  **Avatarınızı Atar**

`)
.setImage("https://cdn.discordapp.com/attachments/760029308214312960/766615035753398282/ezgif.com-crop_1.gif")
.setThumbnail(message.author.avatarURL())
message.channel.send(yardım)

  
   
  
};

exports.conf = {
  enabled: true,
  guildOnly: false, 
  aliases: ['help'], 
  permLevel: 0
};

exports.help = {
  name: "yardım",
  description: 'Bizim yaptığımız bir yardım kodu.',
  usage: 'yardım'
};